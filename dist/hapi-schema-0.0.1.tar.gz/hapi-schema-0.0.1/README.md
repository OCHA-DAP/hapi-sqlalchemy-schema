# hapi-sqlalchemy-schema
Schema for HAPI database in SQLAlchemy
